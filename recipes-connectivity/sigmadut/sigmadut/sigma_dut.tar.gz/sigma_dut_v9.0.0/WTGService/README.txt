
The Wi-Fi Test Suite WTG is used for Wi-Fi Test Suite PC-ENDPOINT (a traffic generator 
sitting behind APs on wired side). If you work on DUT, you should ignore 
this folder
